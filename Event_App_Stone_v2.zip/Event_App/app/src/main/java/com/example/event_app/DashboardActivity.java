package com.example.event_app;

import android.os.Bundle;
import android.widget.Button;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;
import androidx.appcompat.app.AlertDialog;
import android.widget.EditText;
import android.view.View;

public class DashboardActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 1;

    private RecyclerView recyclerView;
    private EventAdapter eventAdapter;
    private List<Event> eventList;
    EventDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getSupportActionBar().hide();

        dbHelper = new EventDatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        eventList = new ArrayList<>();
        eventAdapter = new EventAdapter(eventList, position -> {
            // Delete event
            Event eventToDelete = eventList.get(position);
            dbHelper.deleteEventById(eventToDelete.id);
            eventList.remove(position);
            eventAdapter.notifyItemRemoved(position);
        }, position -> {
            // Edit event
            showEditDialog(position);
        });

        recyclerView.setAdapter(eventAdapter);

        loadEventsFromDB();

        Button addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(v -> {
            // Check permission before sending SMS
            if (PermissionHelper.isSmsPermissionGranted(DashboardActivity.this)) {
                sendSmsNotification("5551234567", "Event Alert: Don't forget about your upcoming event!");
            } else {
                PermissionHelper.requestSmsPermission(DashboardActivity.this);
            }

            // Add new event to the list
            String name = "New Event";
            String date = "2025-04-12";
            String time = "5:00 PM";

            long id = dbHelper.insertEvent(name, date, time);
            if (id != -1) {
                eventList.add(new Event((int) id, name, date, time));
                eventAdapter.notifyItemInserted(eventList.size() - 1);
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionHelper.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    // Send an SMS message
    private void sendSmsNotification(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
    }

    private void loadEventsFromDB() {
        eventList.clear();
        Cursor cursor = dbHelper.getAllEvents();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_NAME));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_DATE));
                String time = cursor.getString(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_TIME));
                eventList.add(new Event(id, name, date, time));
            } while (cursor.moveToNext());
        }
        eventAdapter.notifyDataSetChanged();
    }

    private void showEditDialog(int position) {
        Event event = eventList.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Event");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_event, null);
        EditText nameEdit = dialogView.findViewById(R.id.editEventName);
        EditText dateEdit = dialogView.findViewById(R.id.editEventDate);
        EditText timeEdit = dialogView.findViewById(R.id.editEventTime);

        nameEdit.setText(event.getName());
        dateEdit.setText(event.getDate());
        timeEdit.setText(event.getTime());

        builder.setView(dialogView);
        builder.setPositiveButton("Save", (dialog, which) -> {
            String newName = nameEdit.getText().toString();
            String newDate = dateEdit.getText().toString();
            String newTime = timeEdit.getText().toString();

            dbHelper.updateEvent(event.id, newName, newDate, newTime);
            eventList.set(position, new Event(event.id, newName, newDate, newTime));
            eventAdapter.notifyItemChanged(position);
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }


}
