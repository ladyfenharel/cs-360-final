package com.example.event_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextNewUsername, editTextNewPassword;
    private Button buttonRegister;
    private UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();

        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        buttonRegister = findViewById(R.id.buttonRegister);
        dbHelper = new UserDatabaseHelper(this);

        buttonRegister.setOnClickListener(v -> {
            String newUsername = editTextNewUsername.getText().toString().trim();
            String newPassword = editTextNewPassword.getText().toString().trim();

            if (newUsername.isEmpty() || newPassword.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.registerUser(newUsername, newPassword)) {
                Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                finish(); // Return to login screen
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
