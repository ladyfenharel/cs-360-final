package com.example.event_app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionHelper {

    public static final int SMS_PERMISSION_CODE = 1;

    // Check if SMS permission is granted
    public static boolean isSmsPermissionGranted(AppCompatActivity activity) {
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Request SMS permission
    public static void requestSmsPermission(AppCompatActivity activity) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.SEND_SMS)) {
            Toast.makeText(activity, "SMS permission is needed to send notifications.", Toast.LENGTH_LONG).show();
        }
        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Handle the result of permission request
    public static void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults, AppCompatActivity activity) {
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, do something if needed
                Toast.makeText(activity, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied, handle accordingly
                Toast.makeText(activity, "SMS permission denied. Notifications will not be sent.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
